# Local AI Bot Studio — Android source project

This ZIP contains source files and a GitHub Actions workflow intended to build a debug APK. It does not contain a prebuilt APK.

## Build through GitHub
1. Extract the ZIP.
2. Create a GitHub repository and upload the *contents* of this folder, including `.github/workflows/android-apk.yml`.
3. Push to `main` or open Actions and run **Build Android APK**.
4. If the workflow succeeds, download the `local-ai-bot-studio-debug-apk` artifact from that run and extract it to get `app-debug.apk`.

GitHub can store ZIP files, but uploading a ZIP alone does not compile it into an APK. The workflow has not been run in this chat; wait for GitHub to report success before assuming an APK was built.

## Limitations
- This is a starter prototype, not a production-ready AI system.
- It does not include a full AI model; bot profiles and notes are local.
- Browser reminders cannot guarantee alarms after the app is closed or the phone restarts.
- Imported HTML runs in a sandbox and some files may not work.
